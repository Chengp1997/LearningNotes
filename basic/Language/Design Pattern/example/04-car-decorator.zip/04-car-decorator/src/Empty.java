public class Empty {
//placeholder class
}