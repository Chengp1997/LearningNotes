package cars;

public class ConvertibleDecorator extends CarDecorator {

	public ConvertibleDecorator(Car car) {
		super(car);
	}

	@Override
	public void openRoof() {
		super.setRoofClosed(false, false);
	}

}
