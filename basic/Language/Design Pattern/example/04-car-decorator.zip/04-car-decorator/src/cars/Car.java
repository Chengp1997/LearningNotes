package cars;

public abstract class Car {
	protected Car() {
	}

	public abstract int getSpeed();

	public abstract void setSpeed(int speed);

	protected abstract void setSpeed(int speed, boolean checked);
	
	public abstract int getGear();

	public abstract void setGear(int gear);

	protected abstract void setGear(int gear, boolean checked);

	public abstract int getDirection();
	
	public abstract void turnLeft(int degrees);

	public abstract void turnRight(int degrees);

	public abstract boolean isRoofClosed();

	protected abstract void setRoofClosed(boolean roofClosed, boolean checked);

	public abstract void openRoof();
	
	public abstract void closeRoof();
}
