package cars;

public class CarDecorator extends Car {
	Car baseCar;

	private CarDecorator() {
	}
	
	public CarDecorator(Car baseCar) {
		super();
		this.baseCar = baseCar;
	}
	
	@Override
	public int getSpeed() {
		return baseCar.getSpeed();
	}
	
	@Override
	public void setSpeed(int speed) {
		baseCar.setSpeed(speed);
	}
	
	@Override
	protected void setSpeed(int speed, boolean checked) {
		baseCar.setSpeed(speed, checked);
	}

	@Override
	public int getGear() {
		return baseCar.getGear();
	}
	
	@Override
	protected void setGear(int gear, boolean checked) {
		baseCar.setGear(gear, checked);
	}

	@Override
	public void setGear(int gear) {
		baseCar.setGear(gear);
	}

	@Override
	public int getDirection() {
		return baseCar.getDirection();
	}

	@Override
	public void turnLeft(int degrees) {
		baseCar.turnLeft(degrees);
	}

	@Override
	public void turnRight(int degrees) {
		baseCar.turnRight(degrees);
	}

	@Override
	public boolean isRoofClosed() {
		return baseCar.isRoofClosed();
	}

	@Override
	protected void setRoofClosed(boolean roofClosed, boolean checked) {
		baseCar.setRoofClosed(roofClosed, checked);
		
	}
	
	@Override
	public void openRoof() {
		baseCar.openRoof();
	}

	@Override
	public void closeRoof() {
		baseCar.closeRoof();
	}






}
