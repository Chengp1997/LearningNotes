package cars;

public class SportsCarDecorator extends CarDecorator {

	public SportsCarDecorator(Car car) {
		super(car);
	}

	@Override
	public void setGear(int gear) {
		if (gear < 1 || gear > 6) {
			throw new IllegalArgumentException("SportsCars can only set gear to 1-6!");
		}
		super.setGear(gear, false);
	}

}
