package cars;

public class PoliceCarDecorator extends CarDecorator {

	public PoliceCarDecorator(Car car) {
		super(car);
	}

	public void soundSiren() {
		System.out.println("Siren sounding!");
	}
}

