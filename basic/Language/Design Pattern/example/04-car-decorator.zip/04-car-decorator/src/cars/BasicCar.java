package cars;

public class BasicCar extends Car {
	/** Speed in kilometres per hour */
	protected int speed = 0;
	
	/** Direction the Car is heading, expressed in angle (in degrees) of weels */
	protected int direction = 0;
	
	/** The current setting of the gear */
	protected int gear = 1;
	
	/** Whether the roof is closed or not */
	protected boolean roofClosed = true;


	public BasicCar() {
		super();
	}
	
	public int getSpeed() {
		return speed;
	}
	
	@Override
	protected void setSpeed(int speed, boolean checked) {
		if(checked) {
			if(checkSpeed(speed)) {
				this.speed = speed;
			}
		}
	}
	
	protected boolean checkSpeed(int speed) {
		return true;
	}

	@Override
	public void setSpeed(int speed) {
		setSpeed(speed, true);
	}

	@Override
	public int getGear() {
		return this.gear;
	}

	@Override
	protected void setGear(int gear, boolean checked) {
		if (checked) {
			if (checkGear(gear)) {
				this.gear = gear;
			}
		}
		else {
			this.gear = gear;
		}
	}
	
	protected boolean checkGear(int gear) {
		if (gear < 1 || gear > 5) {
			throw new IllegalArgumentException("BasicCars can only set gear to 1-5!");
		}
		return true;
	}
	
	@Override
	public void setGear(int gear) {
		setGear(gear, true);
	}

	@Override
	public int getDirection() {
		return direction;
	}

	@Override
	public void turnLeft(int degrees) {
		this.direction = (this.direction - degrees) % 360; 
	}

	@Override
	public void turnRight(int degrees) {
		this.direction = (this.direction + degrees) % 360; 
	}

	@Override
	public boolean isRoofClosed() {
		return this.roofClosed;
	}
	
	@Override
	protected void setRoofClosed(boolean roofClosed, boolean checked) {
		if (checked) {
			if(checkRoofClosed(roofClosed)) {
				this.roofClosed = roofClosed;				
			}
		}
		else {
			this.roofClosed = roofClosed;
		}
	}

	protected boolean checkRoofClosed(boolean roofClosed) {
		if (roofClosed) {
			return true;
		}
		else {
			throw new IllegalStateException("BasicCars cannot open their roof!");			
		}
	}
		
	@Override
	public void openRoof() {
		setRoofClosed(false, true);
	}

	@Override
	public void closeRoof() {
		setRoofClosed(true, true);
	}

}
