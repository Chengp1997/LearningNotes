package cars;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Testcase for ConvertibleDecorator class")
public class PoliceCarDecoratorTest extends CarTest {
	public PoliceCarDecoratorTest() {
	}

	@Override
	public Car createCar() {
		return createBasicPoliceCarDecorator();
	}
	
	public static PoliceCarDecorator createBasicPoliceCarDecorator() {
		return new PoliceCarDecorator(new BasicCar());
	}
		
	@Test()
	public void test_PoliceCar_soundSiren_default() {
		PoliceCarDecorator policeCar = createBasicPoliceCarDecorator();
		
		policeCar.soundSiren();
		
		testutils.TestHelper.manualUnitTest("Siren sounded");
	}

}

