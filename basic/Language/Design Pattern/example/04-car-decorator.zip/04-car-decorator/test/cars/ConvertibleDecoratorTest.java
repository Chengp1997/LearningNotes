package cars;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Testcase for ConvertibleDecorator class")
public class ConvertibleDecoratorTest extends CarTest {
	public ConvertibleDecoratorTest() {
	}

	@Override
	public Car createCar() {
		return createBasicConvertibleDecorator();
	}

	public static Car createBasicConvertibleDecorator() {
		return new ConvertibleDecorator(new BasicCar());
	}

	@Override
	@Test()
	public void test_Car_openRoof_default() {
		Car car = createCar();
		
		car.openRoof();
		
		assertEquals(false, car.isRoofClosed());
	}

}

