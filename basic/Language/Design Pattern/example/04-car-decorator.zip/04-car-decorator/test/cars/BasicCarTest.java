package cars;

import org.junit.jupiter.api.DisplayName;

@DisplayName("Testcase for BasicCar class")
public class BasicCarTest extends CarTest {

	public BasicCarTest() {
	}

	@Override
	public Car createCar() {
		return createBasicCar();
	}
	
	public static Car createBasicCar() {
		return new BasicCar();
	}

}
