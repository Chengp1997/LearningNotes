package cars;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

@DisplayName("Testcase for SportsCarDecorator class")
public class SportsCarDecoratorTest extends CarTest {
	public SportsCarDecoratorTest() {
	}

	@Override
	public Car createCar() {
		return createBasicSportsCarDecorator();
	}

	public static Car createBasicSportsCarDecorator() {
		return new SportsCarDecorator(new BasicCar());
	}

	@Override
	@ParameterizedTest
	@ValueSource(ints = { 1, 2, 3, 4, 5, 6 })
	void test_Car_setGear_validGear(int gear) {
		Car car = createCar();

		car.setGear(gear);

		assertEquals(gear, car.getGear());
	}

	@Override
	@Test()
	void test_Car_setSpeed_invalidGear() {
		Car car = createCar();

		assertThrows(IllegalArgumentException.class, () -> {
			car.setGear(7);
		});
	}
}
