package cars;

import org.junit.jupiter.api.DisplayName;

@DisplayName("Testcase for CarDecorator class")
public class CarDecoratorTest extends CarTest {
	public CarDecoratorTest() {
	}

	@Override
	public Car createCar() {
		return createBasicCarDecorator();
	}

	public static Car createBasicCarDecorator() {
		return new CarDecorator(new BasicCar());
	}

}
