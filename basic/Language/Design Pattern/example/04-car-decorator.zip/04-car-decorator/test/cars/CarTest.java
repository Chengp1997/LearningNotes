package cars;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.jupiter.api.DisplayName;

@DisplayName("Base testcase for Car class")
abstract class CarTest {

	public abstract Car createCar();

	@Test
	void test_Car_getSpeed_initialSpeed() {
		Car car = createCar();

		assertEquals(0, car.getSpeed());
	}

	@ParameterizedTest
	@ValueSource(ints = { 0, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120 })
	void test_Car_setSpeed_validSpeed(int speed) {
		Car car = createCar();

		car.setSpeed(speed);

		assertEquals(speed, car.getSpeed());
	}
	@Test void test_Car_getDirection_initialDirection() {
		Car car = createCar();

		assertEquals(0, car.getDirection());
	}

	@Test
	void test_Car_turnLeft_normal() {
		Car car = createCar();

		car.turnLeft(90);

		assertEquals(-90, car.getDirection());
	}

	@Test
	void test_Car_turnLeft_overflow() {
		Car car = createCar();

		for (int i = 0; i < 4; i++) {
			car.turnLeft(90);
		}

		assertEquals(0, car.getDirection(), "After turning 4*90 you should be at the beginning.");
	}

	@Test
	void test_Car_turnRight_normal() {
		Car car = createCar();

		car.turnRight(90);

		assertEquals(90, car.getDirection());
	}

	@Test
	void test_Car_turnRight_overflow() {
		Car car = createCar();

		for (int i = 0; i < 4; i++) {
			car.turnRight(90);
		}

		assertEquals(0, car.getDirection(), "After turning 4*90 you should be at the beginning.");
	}

	
	@Test
	void test_Car_getSpeed_initialGear() {
		Car car = createCar();

		assertEquals(1, car.getGear());
	}

	@ParameterizedTest
	@ValueSource(ints = { 1, 2, 3, 4, 5 })
	void test_Car_setGear_validGear(int gear) {
		Car car = createCar();

		car.setGear(gear);

		assertEquals(gear, car.getGear());
	}

	@Test()
	void test_Car_setSpeed_invalidGear() {
		Car car = createCar();

		assertThrows(IllegalArgumentException.class, () -> {
			car.setGear(6);
		});
	}
	
	@Test()
	public void test_Car_isRoofClosed_initial() {
		Car car = createCar();
		
		assertEquals(true, car.isRoofClosed());
	}

	@Test()
	public void test_Car_openRoof_default() {
		Car car = createCar();

		assertThrows(IllegalStateException.class, () -> {
			car.openRoof();
		});
	}

	@Test()
	public void test_Car_closeRoof_default() {
		Car car = createCar();
		
		car.closeRoof();
		
		assertEquals(true, car.isRoofClosed());
	}
}
