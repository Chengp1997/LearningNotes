public class MenuItem {
    private String label;
    private Operation operation;

    public MenuItem(String label, Operation operation) {
        this.label = label;
        this.operation = operation;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }
}
