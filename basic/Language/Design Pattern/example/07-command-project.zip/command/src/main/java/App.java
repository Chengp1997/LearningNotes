public class App {
    public static void main(String[] args) {
        Menu menu = new Menu();
        MenuItem openMI = new MenuItem("Open", new OpenOperation());
        MenuItem macroMI = new MenuItem("Macro", new MacroOperation());
        menu.addMenuItem(openMI);
        menu.addMenuItem(macroMI);
        menu.displayMenu();
    }
}
