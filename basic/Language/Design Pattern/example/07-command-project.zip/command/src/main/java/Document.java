public class Document {
    public static void open() {

    }
}
