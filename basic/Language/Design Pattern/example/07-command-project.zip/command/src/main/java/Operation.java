public interface Operation {
    public void execute();
}
