public class OpenOperation implements Operation {
    public void execute() {
        Document.open();
    }

}
