
import java.util.List;
import java.util.ArrayList;

public class Menu {
    private List<MenuItem> menuItems;

    public Menu() {
        this.menuItems = new ArrayList<MenuItem>();
    }

    public void addMenuItem(MenuItem mi) {
        this.menuItems.add(mi);
    }

    public void displayMenu() {
        for(MenuItem mi: this.menuItems) {
            System.out.println(mi.getLabel());
        }
    }
}
