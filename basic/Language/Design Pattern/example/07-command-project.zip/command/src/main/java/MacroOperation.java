
import java.util.List;
import java.util.ArrayList;


public class MacroOperation implements Operation {
    private List<Operation> operations;

    public MacroOperation() {
        this.operations = new ArrayList<Operation>();
    }

    public void addOperation(Operation o) {
        this.operations.add(o);
    }

    public void execute() {
        for(Operation o: this.operations) {
            o.execute();
        }
    }
}
