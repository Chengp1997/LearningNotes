package testutils;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class TestHelper {
	public static void manualUnitTest(String assertion) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please check assertion is true: (" + assertion + ") (Y/N)");
		String input = sc.nextLine();

		if (input.contains("Y") || input.contains("y")) {
			return;
		}
		else {
			fail("Failed manual assertion: " + assertion);
		}
	}
	
	public static int generateRandomNumber(int min, int max) {
		Random random = new Random();
		return min + (int)(random.nextFloat() * (max - min + 1));
	}
	
	public static  String generateRandomAlfaString(int minSize, int maxSize) {
	    int leftLimit = 97; // letter 'a'
	    int rightLimit = 122; // letter 'z'

	    int targetStringLength = generateRandomNumber(minSize, maxSize);
	    
	    StringBuilder buffer = new StringBuilder(targetStringLength);
	    for (int i = 0; i < targetStringLength; i++) {
	        int randomLimitedInt = generateRandomNumber(leftLimit, rightLimit);
	        buffer.append((char) randomLimitedInt);
	    }
	    String generatedString = buffer.toString();
	    return generatedString;
	}
}
