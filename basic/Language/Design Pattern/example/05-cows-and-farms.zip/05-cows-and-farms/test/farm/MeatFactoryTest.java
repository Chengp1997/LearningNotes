package farm;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import farm.Meat;
import farm.MeatFactory;

class MeatFactoryTest {

	@Test
	void test_MeatFactory_createMeat_cow() {
		Farm f = new CowFarm();
		MeatFactory mf = new MeatFactory(f);
		Meat m = mf.createMeat();
		
		assertEquals(m.getPricePerKg(), 120);
	}
	
	@Test
	void test_MeatFactory_createMeat_pig() {
		Farm f = new PigFarm();
		MeatFactory mf = new MeatFactory(f);
		Meat m = mf.createMeat();
		
		assertEquals(m.getPricePerKg(), 80);
	}

	@Test
	void test_MeatFactory_createMeat_chicken() {
		Farm f = new ChickenFarm();
		MeatFactory mf = new MeatFactory(f);
		Meat m = mf.createMeat();
		
		assertEquals(m.getPricePerKg(), 75);
	}
}
