package farm;

import testutils.TestHelper;

public class CowFarm extends Farm {
	public Animal createAnimal() {
		return new Cow(TestHelper.generateRandomAlfaString(3, 5),
				TestHelper.generateRandomNumber(10, 20),
				TestHelper.generateRandomNumber(150, 250),
				Gender.MALE);
	}
}
