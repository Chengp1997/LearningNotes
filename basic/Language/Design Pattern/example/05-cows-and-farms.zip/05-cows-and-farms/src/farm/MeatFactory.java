package farm;

public class MeatFactory {
	private Farm farm;
	
	public MeatFactory(Farm farm) {
		super();
		this.farm = farm;
	}
	
	public Meat createMeat() {
		Animal animal;
		animal = farm.createAnimal();
		return animal.convertToMeat();
	}
}
