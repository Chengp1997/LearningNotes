package farm;

public class Chicken extends Animal {
	
	public Chicken(String name, int ageInWeeks, int weightInKg, Gender gender) {
		super(name, ageInWeeks, weightInKg, gender);
	}

	@Override
	public Meat convertToMeat() {
		return new Meat(this.getWeightInKg(), 75);
	}

}
