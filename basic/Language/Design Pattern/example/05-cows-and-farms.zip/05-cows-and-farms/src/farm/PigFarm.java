package farm;

import testutils.TestHelper;

public class PigFarm extends Farm {
	public Animal createAnimal() {
		return new Pig(TestHelper.generateRandomAlfaString(3, 5),
				TestHelper.generateRandomNumber(10, 30),
				TestHelper.generateRandomNumber(100, 120),
				Gender.MALE);
	}
}
