package farm;

public class Meat {
	private int weightInKg;
	private int pricePerKg;
	
	public Meat(int weightInKg, int pricePerKg) {
		super();
		this.weightInKg = weightInKg;
		this.pricePerKg = pricePerKg;
	}
	
	public int getWeightInKg() {
		return weightInKg;
	}
	
	public void setWeightInKg(int weightInKg) {
		this.weightInKg = weightInKg;
	}
	
	public int getPricePerKg() {
		return pricePerKg;
	}
	
	public void setPricePerKg(int pricePerKg) {
		this.pricePerKg = pricePerKg;
	}
	
}
