package farm;

import testutils.TestHelper;

public class ChickenFarm extends Farm {
	public Animal createAnimal() {
		return new Chicken(TestHelper.generateRandomAlfaString(3, 5),
				TestHelper.generateRandomNumber(1, 5),
				TestHelper.generateRandomNumber(1, 5),
				Gender.MALE);
	}
}
