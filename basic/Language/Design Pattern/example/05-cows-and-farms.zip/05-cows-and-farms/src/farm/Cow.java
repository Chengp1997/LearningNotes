package farm;

public class Cow extends Animal {
	
	public Cow(String name, int ageInWeeks, int weightInKg, Gender gender) {
		super(name, ageInWeeks, weightInKg, gender);
	}

	@Override
	public Meat convertToMeat() {
		return new Meat(this.getWeightInKg(), 120);
	}

}
