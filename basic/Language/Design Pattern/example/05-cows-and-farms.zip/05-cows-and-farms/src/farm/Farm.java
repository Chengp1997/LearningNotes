package farm;

public abstract class Farm {
	public abstract Animal createAnimal();
}
