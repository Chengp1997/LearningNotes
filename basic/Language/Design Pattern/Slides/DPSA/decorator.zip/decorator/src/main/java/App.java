public class App {

    public static void main() {
        Car car = new SpeedLimitedCar(new BasicCar());
    }
}

