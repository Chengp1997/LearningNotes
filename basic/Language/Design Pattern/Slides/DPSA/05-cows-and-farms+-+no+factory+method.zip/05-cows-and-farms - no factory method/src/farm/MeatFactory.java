package farm;

public class MeatFactory {
	private CowFarm cFarm;
	private PigFarm pFarm;
	private String type = "cow";
	
	
	public MeatFactory(CowFarm farm) {
		super();
		this.farm = farm;
	}
	
	public setType(String type) {
		this.type = type;
	}

	public Meat createMeat() {
		Animal animal;
		if (type == "cow") {
			animal = cFarm.createAnimal();
		}
		else {
			animal = pFarm.createAnimal();
		}
		return animal.convertToMeat();
	}
}
