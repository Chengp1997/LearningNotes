package farm;

public class Pig extends Animal {

	public Pig(String name, int ageInWeeks, int weightInKg, Gender gender) {
		super(name, ageInWeeks, weightInKg, gender);
	}

	@Override
	public Meat convertToMeat() {
		return new Meat(this.getWeightInKg(), 80);
	}
}
