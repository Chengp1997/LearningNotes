package farm;

public abstract class Animal {
	private String name;
	private int ageInWeeks;
	private int weightInKg;
	private Gender gender;

	public Animal(String name, int ageInWeeks, int weightInKg, Gender gender) {
		super();
		this.name = name;
		this.ageInWeeks = ageInWeeks;
		this.weightInKg = weightInKg;
		this.gender = gender;
	}

	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAgeInWeeks() {
		return ageInWeeks;
	}


	public void setAgeInWeeks(int ageInWeeks) {
		this.ageInWeeks = ageInWeeks;
	}


	public int getWeightInKg() {
		return weightInKg;
	}


	public void setWeightInKg(int weightInKg) {
		this.weightInKg = weightInKg;
	}


	public Gender getGender() {
		return gender;
	}


	public void setGender(Gender gender) {
		this.gender = gender;
	}


	public abstract Meat convertToMeat();
}
