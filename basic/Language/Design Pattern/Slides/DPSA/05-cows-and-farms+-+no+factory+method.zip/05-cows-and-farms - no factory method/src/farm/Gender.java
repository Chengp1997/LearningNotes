package farm;

public enum Gender {
	MALE, FEMALE;
}
