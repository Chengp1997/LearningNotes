package software.testing.fourinarow;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FourInARowGameTest {

    @Test
    public void shouldNotBeSinglePlayerModeWhenInitialised(){
        FourInARowGame game = new FourInARowGame();
        assertEquals(false, game.isSinglePlayer());
    }

    @Test
    public void shouldSetSinglePlayerMode(){
        FourInARowGame game = new FourInARowGame();
        game.setSinglePlayer(true);
        assertEquals(true, game.isSinglePlayer());
    }

    @Test
    public void shouldInitialiseAnEmptyBoardOfSixBySeven(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        assertEquals(6,board.length);
        assertEquals(7,board[0].length);
        for(int row = 0; row < board.length; row++) {
            for(int column = 0; column < board.length; column++) {
                assertEquals(board[row][column], BoardCellStatus.EMPTY);
            }
        }
    }

    @Test
    public void shouldGetRow3AsEmptyRowIfTwoCellsAreOccupied(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][1] = BoardCellStatus.PLAYER_ONE;
        board[4][1] = BoardCellStatus.PLAYER_ONE;
        assertEquals(3, game.getEmptyRow(1));
    }

    @Test
    public void shouldGet5AsEmptyIfColumnIsEmpty(){
        FourInARowGame game = new FourInARowGame();
        game.initialiseBoard();
        assertEquals(5, game.getEmptyRow(5));
    }

    @Test
    public void shouldGetMinusOneEmptyRowIfColumnIsFull(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][1] = BoardCellStatus.PLAYER_ONE;
        board[4][1] = BoardCellStatus.PLAYER_ONE;
        board[3][1] = BoardCellStatus.PLAYER_ONE;
        board[2][1] = BoardCellStatus.PLAYER_ONE;
        board[1][1] = BoardCellStatus.PLAYER_ONE;
        board[0][1] = BoardCellStatus.PLAYER_ONE;
        assertEquals(-1, game.getEmptyRow(1));
    }

    //winning vertically test
    @Test
    public void shouldWinVerticallyAndGameIsOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][0]=BoardCellStatus.PLAYER_ONE;
        board[4][0]=BoardCellStatus.PLAYER_ONE;
        board[3][0]=BoardCellStatus.PLAYER_ONE;
        board[2][0]=BoardCellStatus.PLAYER_ONE;
        assertEquals(true, game.consecutiveVertically(new GridPosition(2,0)));
        assertTrue(game.gameOver(new GridPosition(2,0)));
    }

    @Test
    public void shouldNotWinVerticallyIfInterruptedAndGameIsNotOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][0]=BoardCellStatus.PLAYER_ONE;
        board[4][0]=BoardCellStatus.PLAYER_ONE;
        board[3][0]=BoardCellStatus.PLAYER_ONE;
        board[2][0]=BoardCellStatus.PLAYER_TWO;
        assertEquals(false, game.consecutiveVertically(new GridPosition(2,0)));
        assertFalse(game.gameOver(new GridPosition(2,0)));
    }

    @Test
    public void shouldNotWinVerticallyIfNotEnoughAndGameIsNotOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][0]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveVertically(new GridPosition(5,0)));
        assertFalse(game.gameOver(new GridPosition(5,0)));
        board[4][0]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveVertically(new GridPosition(4,0)));
        assertFalse(game.gameOver(new GridPosition(4,0)));
        board[3][0]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveVertically(new GridPosition(3,0)));
        assertFalse(game.gameOver(new GridPosition(3,0)));
    }

    //winning horizontally test
    @Test
    public void shouldWinHorizontallyAndGameIsOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][1]=BoardCellStatus.PLAYER_ONE;
        board[5][0]=BoardCellStatus.PLAYER_ONE;
        board[5][2]=BoardCellStatus.PLAYER_ONE;
        board[5][3]=BoardCellStatus.PLAYER_ONE;
        assertEquals(true, game.consecutiveHorizontally(new GridPosition(5,3)));
        assertEquals(true, game.gameOver(new GridPosition(5,3)));
    }

    @Test
    public void shouldNotWinHorizontally1IfInterruptedAndGameIsNotOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][1]=BoardCellStatus.PLAYER_ONE;
        board[5][0]=BoardCellStatus.PLAYER_ONE;
        board[5][2]=BoardCellStatus.PLAYER_ONE;
        board[5][3]=BoardCellStatus.PLAYER_TWO;
        assertEquals(false, game.consecutiveHorizontally(new GridPosition(5,3)));
        assertEquals(false,game.gameOver(new GridPosition(5,2)));
    }

    @Test
    public void shouldNotWinHorizontallyIfNotEnoughAndGameIsNotOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][1]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveHorizontally(new GridPosition(5,1)));
        assertEquals(false,game.gameOver(new GridPosition(5,1)));
        board[5][0]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveHorizontally(new GridPosition(5,0)));
        assertEquals(false,game.gameOver(new GridPosition(5,0)));
        board[5][2]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveHorizontally(new GridPosition(5,2)));
        assertEquals(false,game.gameOver(new GridPosition(5,2)));
    }

    //winning diagonally1 test
    @Test
    public void  shouldWinDiagonally1(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();

        board[5][1]=BoardCellStatus.PLAYER_ONE;
        board[4][2]=BoardCellStatus.PLAYER_ONE;
        board[3][3]=BoardCellStatus.PLAYER_ONE;
        board[2][4]=BoardCellStatus.PLAYER_ONE;
        assertEquals(true, game.consecutiveDiagonally1(new GridPosition(4,2)));
    }

    @Test
    public void  shouldNotWinDiagonally1IfIfInterruptedAndGameIsNotOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();

        board[5][1]=BoardCellStatus.PLAYER_ONE;
        board[3][3]=BoardCellStatus.PLAYER_ONE;
        board[2][4]=BoardCellStatus.PLAYER_ONE;
        board[4][2]=BoardCellStatus.PLAYER_TWO;
        assertEquals(false, game.consecutiveDiagonally1(new GridPosition(4,2)));
        assertEquals(false,game.gameOver(new GridPosition(4,2)));
    }

    @Test
    public void  shouldNotWinDiagonally1IfIfNotEnoughAndGameIsNotOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][1]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveDiagonally1(new GridPosition(5,1)));
        assertEquals(false,game.gameOver(new GridPosition(5,1)));
        board[4][2]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveDiagonally1(new GridPosition(4,2)));
        assertEquals(false,game.gameOver(new GridPosition(4,2)));
        board[3][3]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveDiagonally1(new GridPosition(3,3)));
        assertEquals(false,game.gameOver(new GridPosition(3,3)));
    }

    //winning Diagonally2 test
    @Test
    public void  shouldWinDiagonally2(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][4]=BoardCellStatus.PLAYER_ONE;
        board[4][3]=BoardCellStatus.PLAYER_ONE;
        board[3][2]=BoardCellStatus.PLAYER_ONE;
        board[2][1]=BoardCellStatus.PLAYER_ONE;
        assertEquals(true, game.consecutiveDiagonally2(new GridPosition(2,1)));
    }

    @Test
    public void  shouldNotWinDiagonally2IfIfInterruptedAndGameIsNotOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][4]=BoardCellStatus.PLAYER_ONE;
        board[4][3]=BoardCellStatus.PLAYER_ONE;
        board[2][1]=BoardCellStatus.PLAYER_ONE;
        board[3][2]=BoardCellStatus.PLAYER_TWO;
        assertEquals(false, game.consecutiveDiagonally2(new GridPosition(3,2)));
    }

    @Test
    public void  shouldNotWinDiagonally2IfIfNotEnoughAndGameIsNotOver(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        board[5][4]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveDiagonally2(new GridPosition(5,4)));
        board[4][3]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveDiagonally2(new GridPosition(4,3)));
        board[2][1]=BoardCellStatus.PLAYER_ONE;
        assertEquals(false, game.consecutiveDiagonally2(new GridPosition(2,1)));
    }

    @Test
    public void shouldHaveEmptyRecordsInitially(){
        FourInARowGame game = new FourInARowGame();
        String expected = "0 moves in total.";
        assertEquals(expected, game.getAllMovements());
    }

    @Test
    public void shouldRecordMovement(){
        FourInARowGame game = new FourInARowGame();
        game.addMovement(new GridPosition(5,4));
        game.addMovement(new GridPosition(5,3));

        String expected = "(5, 4) (5, 3) 2 moves in total.";
        assertEquals(expected, game.getAllMovements());
    }

    @Test
    public void shouldNotBeAbleToUndo(){
        FourInARowGame game = new FourInARowGame();
        game.setSinglePlayer(false);
        assertEquals(true, game.cannotUndo());
        game.setSinglePlayer(true);
        assertEquals(true, game.cannotUndo());
    }

    @Test
    public void shouldUndoOneMoveForTwoPlayerGame(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        game.setSinglePlayer(false);

        game.addMovement(new GridPosition(5,4));
        board[5][4] = BoardCellStatus.PLAYER_ONE;

        game.addMovement(new GridPosition(5,3));
        board[5][3] = BoardCellStatus.PLAYER_TWO;

        game.undo();
        String expected = "(5, 4) 1 moves in total.";
        assertEquals(expected, game.getAllMovements());
        assertEquals(BoardCellStatus.EMPTY, board[5][3]);
    }


    @Test
    public void shouldUndoTwoMoveForSinglePlayerGame(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        game.setSinglePlayer(true);

        game.addMovement(new GridPosition(5,4));
        board[5][4] = BoardCellStatus.PLAYER_ONE;

        game.addMovement(new GridPosition(4,4));
        board[4][4] = BoardCellStatus.PLAYER_TWO;

        game.undo();
        String expected = "0 moves in total.";
        assertEquals(expected, game.getAllMovements());
        assertEquals(BoardCellStatus.EMPTY, board[5][4]);
        assertEquals(BoardCellStatus.EMPTY, board[4][4]);
    }

    @Test
    public void shouldNotBeAbleToRedo(){
        FourInARowGame game = new FourInARowGame();
        game.setSinglePlayer(false);
        assertEquals(true, game.cannotRedo());
        game.setSinglePlayer(true);
        assertEquals(true, game.cannotRedo());
    }

    @Test
    public void shouldRedoOneMoveForTwoPlayerGame(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        game.setSinglePlayer(false);

        game.addMovement(new GridPosition(5,4));
        board[5][4] = BoardCellStatus.PLAYER_ONE;

        game.addMovement(new GridPosition(5,3));
        board[5][3] = BoardCellStatus.PLAYER_TWO;

        game.undo();
        game.redo(BoardCellStatus.PLAYER_TWO);
        String expected = "(5, 4) (5, 3) 2 moves in total.";
        assertEquals(expected, game.getAllMovements());
        assertEquals(BoardCellStatus.PLAYER_TWO, board[5][3]);
    }

    @Test
    public void shouldRedoTwoMovesForSinglePlayerGame(){
        FourInARowGame game = new FourInARowGame();
        BoardCellStatus[][] board = game.initialiseBoard();
        game.setSinglePlayer(true);

        game.addMovement(new GridPosition(5,4));
        board[5][4] = BoardCellStatus.PLAYER_ONE;

        game.addMovement(new GridPosition(4,4));
        board[4][4] = BoardCellStatus.PLAYER_TWO;

        game.undo();
        game.redo(BoardCellStatus.PLAYER_ONE);
        String expected = "(5, 4) (4, 4) 2 moves in total.";
        assertEquals(expected, game.getAllMovements());
        assertEquals(BoardCellStatus.PLAYER_ONE, board[5][4]);
        assertEquals(BoardCellStatus.PLAYER_TWO, board[4][4]);
    }

    @Test
    public void shouldClearCache(){
        FourInARowGame game = new FourInARowGame();
        game.clearCache();

        assertEquals(0, game.getMoves().size());
        assertEquals(0, game.getUndoneMoves().size());
    }

    @Test
    public void shouldGenerateValidRandomPosition(){
        FourInARowGame game = new FourInARowGame();
        game.initialiseBoard();
        GridPosition position = game.getRandomPosition();

        assertTrue(position.getColumn()<=6 && position.getColumn()>=0);
        assertTrue(position.getRow()<=5 && position.getRow()>=0);
    }

    @Test
    public void shouldGetNextStatus(){
        FourInARowGame game = new FourInARowGame();
        assertEquals(BoardCellStatus.PLAYER_ONE,game.getNextStatus(BoardCellStatus.PLAYER_TWO));
        assertEquals(BoardCellStatus.PLAYER_TWO, game.getNextStatus(BoardCellStatus.PLAYER_ONE));
    }
}
