package software.testing.fourinarow;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FourInARowGame {
    private BoardCellStatus[][] board = null;
    /**
     * list of movements
     */
    private List<GridPosition> moves = new ArrayList<>();

    /**
     * list of undone movements
     */
    private List<GridPosition> undoneMoves = new ArrayList<>();
    /**
     * mode of the game
     * true when it's a single player game, false otherwise
     */
    private boolean singlePlayer = false;

    public void setSinglePlayer(boolean mode){
        singlePlayer = mode;
    }

    public boolean isSinglePlayer() {
        return singlePlayer;
    }

    public List<GridPosition> getMoves() {
        return moves;
    }

    public List<GridPosition> getUndoneMoves() {
        return undoneMoves;
    }

    /**
     * Initialises the two dimensional array with empty positions.
     * @return an empty board of 6 × 7
     */
    public BoardCellStatus[][] initialiseBoard(){
        board = new BoardCellStatus[6][7];
        for(int row = 0; row < board.length; row++) {
            for(int column = 0; column < board[0].length; column++) {
                board[row][column] = BoardCellStatus.EMPTY;
            }
        }
        return board;
    }

    /**
     * @param selectedColumn
     * @return the index of the lowest empty row in the selected column
     */
    public int getEmptyRow(int selectedColumn){
        int emptyRow = -1;
        for(int row = 5 ; row >= 0; row--) {
            if(board[row][selectedColumn] == BoardCellStatus.EMPTY) {
                emptyRow = row;
                break;
            }
        }
        return emptyRow;
    }

    /**
     * add this new position to the movement list
     * @param position the square's position
     */
    public void addMovement(GridPosition position){
        moves.add(position);
    }

    /**
     * after a player takes a move, check if he has won
     * @param position
     * @return true if player has won, false if player has not won
     */
    public boolean gameOver(GridPosition position){
        return consecutiveVertically(position)
                ||consecutiveHorizontally(position)
                ||consecutiveDiagonally1(position)
                ||consecutiveDiagonally2(position);
    }

    /**
     * check if there are four vertically consecutive squares
     * @param position
     * @return
     */
    public boolean consecutiveVertically(GridPosition position){
        int row = position.getRow();
        int column = position.getColumn();
        if(row<3
                && board[row][column]==board[row+1][column]
                && board[row][column]==board[row+2][column]
                && board[row][column]==board[row+3][column])
            return true;
        else
            return false;
    }

    /**
     * check if there are four horizontally consecutive squares
     * @param position
     * @return
     */
    public boolean consecutiveHorizontally(GridPosition position){
        int row = position.getRow();
        int column = position.getColumn();
        int leftStart = column;
        int current = column;
        // find the most left one of consecutive four squares
        while(true){
            if(current--<=0){
                break;
            }
            else{
                if(board[row][column] == board[row][current]){
                    leftStart = current;
                }
            }
        }


        if(leftStart<4
                && board[row][leftStart] == board[row][leftStart+1]
                && board[row][leftStart] == board[row][leftStart+2]
                && board[row][leftStart] == board[row][leftStart+3])
            return true;
        else
            return false;
    }

    /**
     * check if there are four diagonally consecutive squares whose row index goes down as column index goes up
     * @param position
     * @return
     */
    public boolean consecutiveDiagonally1(GridPosition position){
        int row = position.getRow();
        int column = position.getColumn();
        int leftStartColumn = column;
        int leftStartRow = row;
        int currentColumn = column;
        int currentRow = row;

        // find the most left one of consecutive four squares
        while(true){
            currentColumn--;
            currentRow++;
            if(currentColumn<0 || currentRow>5) {
                break;
            }
            else{
                if(board[row][column] == board[currentRow][currentColumn]){
                    leftStartColumn = currentColumn;
                    leftStartRow = currentRow;
                }
            }
        }

        if(leftStartColumn<=3 && leftStartRow>=3
                && board[leftStartRow][leftStartColumn] == board[leftStartRow-1][leftStartColumn+1]
                && board[leftStartRow][leftStartColumn] == board[leftStartRow-2][leftStartColumn+2]
                && board[leftStartRow][leftStartColumn] == board[leftStartRow-3][leftStartColumn+3])
            return true;
        else
            return false;
    }

    /**
     * check if there are four diagonally consecutive squares whose row index goes up as column index goes up
     * @param position
     * @return
     */
    public boolean consecutiveDiagonally2(GridPosition position){
        int row = position.getRow();
        int column = position.getColumn();
        int leftStartColumn = column;
        int leftStartRow = row;
        int currentColumn = column;
        int currentRow = row;

        // find the most left one of consecutive four squares
        while(true){
            currentColumn--;
            currentRow--;
            if(currentColumn<0 || currentRow<0) {
                break;
            }
            else{
                if(board[row][column] == board[currentRow][currentColumn]){
                    leftStartColumn = currentColumn;
                    leftStartRow = currentRow;
                }
            }
        }
        if(leftStartColumn<=3 && leftStartRow<=2
                && board[leftStartRow][leftStartColumn] == board[leftStartRow+1][leftStartColumn+1]
                && board[leftStartRow][leftStartColumn] == board[leftStartRow+2][leftStartColumn+2]
                && board[leftStartRow][leftStartColumn] == board[leftStartRow+3][leftStartColumn+3])
            return true;
        else
            return false;
    }

    public String getAllMovements(){
        String tmp = "";
        for(int i=0;i<moves.size();i++){
            tmp+="("+moves.get(i).getRow()+", "+moves.get(i).getColumn()+") ";
        }
        tmp+=moves.size()+" moves in total.";
        return tmp;
    }

    /**
     *
     * @return false is there are no more movements to undo
     */
    public boolean cannotUndo(){
        return moves.size()==0;
    }

    /**
     * undo one movement if it's a two player game,
     * and undo two movements if it's a single player game
     */
    public BoardCellStatus[][] undo(){
        GridPosition undoneMove = moves.get(moves.size()-1);
        board[undoneMove.getRow()][undoneMove.getColumn()] = BoardCellStatus.EMPTY;
        moves.remove(moves.size()-1);
        undoneMoves.add(undoneMove);
        if(singlePlayer){
            //undo again
            undoneMove = moves.get(moves.size()-1);
            board[undoneMove.getRow()][undoneMove.getColumn()] = BoardCellStatus.EMPTY;
            moves.remove(moves.size()-1);
            undoneMoves.add(undoneMove);
            }
        return board;
    }

    /**
     *
     * @return false is there are no more movements to redo
     */
    public boolean cannotRedo(){
        return undoneMoves.size()==0;//no more movements to redo
    }

    /**
     * redo one move if it's a two player game
     * redo two moves if it's a single player game
     * @param status current player
     */
    public BoardCellStatus[][] redo(BoardCellStatus status){
        BoardCellStatus nextStatus = getNextStatus(status);

        GridPosition undoneMove = undoneMoves.get(undoneMoves.size()-1);
        addMovement(undoneMove);
        board[undoneMove.getRow()][undoneMove.getColumn()] = status;
        undoneMoves.remove(undoneMoves.size()-1);

        if(singlePlayer){
            //redo again
            undoneMove = undoneMoves.get(undoneMoves.size()-1);
            addMovement(undoneMove);
            board[undoneMove.getRow()][undoneMove.getColumn()] = nextStatus;
            undoneMoves.remove(undoneMoves.size()-1);
        }
        return board;
    }

    /**
     * clear the list of movements and undone movements
     */
    public void clearCache(){
        moves.clear();
        clearUndoneMovementList();
    }

    public void clearUndoneMovementList(){
        undoneMoves.clear();
    }

    /**
     *
     * @param status current player
     * @return the next player
     */
    public BoardCellStatus getNextStatus(BoardCellStatus status){
        if (status==BoardCellStatus.PLAYER_ONE)
            return BoardCellStatus.PLAYER_TWO;
        else
            return BoardCellStatus.PLAYER_ONE;
    }

    /**
     * @return a valid random position for the computer in a single player game
     */
    public GridPosition getRandomPosition(){
        Random random = new Random();
        int emptyRow, selectedColumn;
        while(true){
            selectedColumn = random.nextInt(6);
            emptyRow = getEmptyRow(selectedColumn);
            if (emptyRow != -1){
                GridPosition position = new GridPosition(emptyRow, selectedColumn);
                return position;
            }
        }
    }
}
