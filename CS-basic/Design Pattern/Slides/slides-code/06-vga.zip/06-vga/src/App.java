
public class App {
	public static VgaAdapter vga = new VgaAdapter();

	
	public static void main(String[] args) {
		VgaAdapterStatic st = null; // might never be used
		VgaAdapter vga1 = new VgaAdapter();
		// do something with vga1


		VgaAdapter vga2 = new VgaAdapter();
		// do something with vga2 => conflict vga1

	}

}
