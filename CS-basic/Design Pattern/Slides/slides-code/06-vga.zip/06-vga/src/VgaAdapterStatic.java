
public class VgaAdapterStatic {
	private static boolean state;
	
	protected VgaAdapterStatic() {
	}
	
	public static void setPixel(int x, int y, Color c) {
		if (state == true) {
			// do something with hardware
		}
	}
	
	public static void turnOn() {
		// do something with hardware
		state = true;
	}

	public static void turnOff() {
		// do something with hardware
		state = false;
	}

}
