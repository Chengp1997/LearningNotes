
public class VgaAdapterInstanceField {
	private volatile static VgaAdapterInstanceField vgaAdapter = null;
	private boolean state;

	protected VgaAdapterInstanceField() {
		// takes a very very very long time to execute..
	}
	
	public static VgaAdapterInstanceField getInstance() {
		if (vgaAdapter == null) {
			synchronized (VgaAdapterInstanceField.class) {
				if (vgaAdapter == null) {
					vgaAdapter = new VgaAdapterInstanceField();
				}
			}
		}
		return vgaAdapter; // prevent overwriting the reference
	}
	
	public void setPixel(int x, int y, Color c) {
		if (state == true) {
			// do something with hardware
		}
	}
	
	public void turnOn() {
		// do something with hardware
		state = true;
	}

	public void turnOff() {
		// do something with hardware
		state = false;
	}

}
