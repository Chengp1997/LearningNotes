
public class Color {

}
