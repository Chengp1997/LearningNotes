
public class VgaAdapterStaticField {
	private static VgaAdapterStaticField vgaAdapter = new VgaAdapterStaticField();
	private boolean state;

	protected VgaAdapterStaticField() {
		// takes a very very very long time to execute..
	}
	
	public static VgaAdapterStaticField getInstance() {
		return vgaAdapter; // prevent overwriting the reference
	}
	
	public void setPixel(int x, int y, Color c) {
		if (state == true) {
			// do something with hardware
		}
	}
	
	public void turnOn() {
		// do something with hardware
		state = true;
	}

	public void turnOff() {
		// do something with hardware
		state = false;
	}

}
