public class GraphicsCard {
    private volatile static GraphicsCard graphicsCard;

    private GraphicsCard() {
    }

    public static GraphicsCard getGraphicsCard() {
        if (graphicsCard == null) {
            synchronized (GraphicsCard.class) {
                if (graphicsCard == null) {
                    graphicsCard = new GraphicsCard();
                }
            }
        }
        return graphicsCard;
    }
}