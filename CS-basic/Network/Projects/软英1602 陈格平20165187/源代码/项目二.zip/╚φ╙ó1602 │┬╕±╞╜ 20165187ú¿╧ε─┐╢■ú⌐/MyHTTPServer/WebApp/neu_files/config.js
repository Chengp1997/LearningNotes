seajs.config({
  base: "./mods/",
  alias: {
    "jquery": "jquery.js",
    "respond": "respond.min.js",
    "nav": "nav.js",
    "slide": "responsiveslides.js",
    "smallslider": "smallslider.js"
  }
});
