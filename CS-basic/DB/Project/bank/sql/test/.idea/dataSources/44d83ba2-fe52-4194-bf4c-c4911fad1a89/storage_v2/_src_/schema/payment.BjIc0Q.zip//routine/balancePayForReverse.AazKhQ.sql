CREATE PROCEDURE balancePayForReverse(IN p_DID INT, IN p_serialNumber DOUBLE, IN selectedDay DATE)
  BEGIN

    declare userBalance double;
    declare accountNumber double;
    declare p_ID int;
    declare count int;
    declare p_username varchar(20);
    declare p_capital double;
    declare p_overduefine double;
    declare p_receivedAmount double;
    declare p_payableDate date;
    declare shouldPay double;
    declare done Integer default 0;
    declare userBalanceBefore double;
    declare userBalance2 double;
    declare totalAmount double default 0;
    declare p_beginMeterAmount int;
    declare p_basicAmount double;
    declare appendFee2Rate double;
    declare p_deviceType varchar(5);
    declare notice varchar(20);
    declare i int;
    
    select balance,ID into userBalance,p_ID from deviceuser join device using(ID) where DID=p_DID;-- 获得此用户余额
    set userBalanceBefore=userBalance;
    set userBalance2=userBalance;
    select count(*) into count from arrearagerecord where DID=p_DID and finish=0;
-- 从余额扣费，将欠费记录补上   类似于缴费过程
    
    if(ifnull(count,0)>0) then -- 有欠费记录,补欠费记录
   
        if(userBalance>0) then
        set i=0;
            exitLable: begin
                while(i<count) do
             
                if(userBalance=0) then
                    leave exitLable;
                end if;
                select username, capital, overduefine, receivedAmount, payableDate, DID
                into p_username, p_capital, p_overduefine, p_receivedAmount, p_payableDate, p_DID
                from (select id, username,capital,(capital*0) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where  selectedDay<=payableDate and selectedDay>=arrearageDate and finish=0
                    union
                    /*01设备*/
                    /*超过应缴日期未还款*/
                    select id, username,capital,(capital*datediff(selectedDay,payableDate)*0.001) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=01 and selectedDay>payableDate and finish=0
                    union
                    /*02设备*/
                    /*跨年*/
                    select id, username, capital,(capital*(datediff(selectedDay,date_sub(selectedDay,interval dayofyear(now())-1 day))+1)*0.002
                                                            +capital*(datediff(date_sub(selectedDay,interval dayofyear(selectedDay)-1 day),payableDate))*0.003) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=02 and year(payableDate)<year(selectedDay) and finish=0
                    union
                    /*未跨年*/
                    select id, username,capital,(capital*(datediff(selectedDay,date_sub(selectedDay,interval dayofyear(selectedDay)-1 day))+1)*0.002) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=02 and year(payableDate)=year(selectedDay) and finish=0
                    union
                    select id, username, capital, overduefine,receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where finish=1) T
                where T.DID=p_DID and T.finish=0
                order by payableDate asc
                limit 0,1;
                    -- 开始进行缴费操作
                    set shouldPay=p_capital+p_overduefine-p_receivedAmount;
                    set totalAmount=totalAmount+shouldPay;
                    select totalAmount,shouldPay;
                    if(userBalance>shouldPay) then -- 如果余额足够支付
                        set userBalance=userBalance-shouldPay;
                        
                        update arrearagerecord
                        set receivedAmount=p_capital+p_overduefine,actualReceivebleAmount=p_capital+p_overduefine,payDate=@selectedDay,overdueFine=p_overduefine,finish=1
                        where DID=p_DID and payableDate=p_payableDate;
                    else
                        
                        update arrearagerecord
                        set receivedAmount=userBalance
                        where DID=p_DID and payableDate=p_payableDate;
                        set userBalance=0;  
                        
                    end if;
                 
                    insert into balancechangesrecord(ID, changeTime,beforeChange,afterChange,changeAmount,reason)
                    values(p_ID, current_timestamp(),userBalanceBefore,userBalance,userBalanceBefore-userBalance,'01');
                    set userBalanceBefore=userBalance;
                    set i=i+1;
               
                end while;
                end exitLable;
        end if;
        
        
         update deviceuser set balance=userBalance
         where ID=p_ID;
         
         if(userBalance2<totalAmount) then
            update paymentrecord
            set inDeviceAmount=userBalance2
            where serialNumber=p_serialNumber;
         else
            update paymentrecord
            set inDeviceAmount=totalAmount
            where serialNumber=p_serialNumber;
         end if;
    end if;
END;

