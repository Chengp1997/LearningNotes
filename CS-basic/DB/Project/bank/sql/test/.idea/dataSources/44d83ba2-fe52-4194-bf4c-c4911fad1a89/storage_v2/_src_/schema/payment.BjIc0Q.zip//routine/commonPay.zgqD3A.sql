CREATE PROCEDURE commonPay(IN serialNumber DOUBLE, IN p_ID INT, IN p_accountNumber INT, IN p_paymentAmount DOUBLE,
                           IN p_DID        INT, IN selectedDay DATE)
  BEGIN
    declare countDID int;
    declare notice varchar(500);
    declare countDate int;
    declare p_payableDate date;
    declare countAccount double;
    declare serialNum int;
    declare i int;
    declare p_bankID varchar(20) ;
    declare actualFee double;
    declare p_receivedAmount double;
    declare userBalance double;
    declare userBalance2 double;
    declare p_ID_to int;
    declare storeBalance double;
    -- 用于记录原值，用来最后更新用户余额以及缴费记录表
    declare p_paymentAmount2 double;
    set p_paymentAmount2=p_paymentAmount;
    
    -- 查找是否有此设备,该设备主人为谁
    select count(*),ID into countDID,p_ID_to from device where DID=p_DID;
    select bankID into p_bankID from bankaccount where accountNumber=p_accountNumber;
            if(p_ID=p_ID_to) then
                select balance into userBalance from deviceuser where ID=p_ID;-- 获得我的用户余额
            else
                set userBalance=0;
            end if;
            set userBalance2=userBalance;
        
                select count(*) into countDate from arrearagerecord where DID=p_DID and finish=0;-- 这台设备一共有几个欠费记录
                set i=0;
                outer_lable: BEGIN
                    if(countDate=i) then
                        set notice='已无欠费账单' ;
                        select notice;-- 之后将多交的钱转入余额
                    else
                        while i<countDate do
                            
                            select payableDate,(overdueFine+capital),receivedAmount into p_payableDate,actualFee, p_receivedAmount 
							   from (select id, username,capital,(capital*0) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
									from device join deviceuser using (ID) join arrearagerecord using(DID)
									where  selectedDay<=payableDate and selectedDay>=arrearageDate and finish=0
									union
									/*01设备*/
									/*超过应缴日期未还款*/
									select id, username,capital,(capital*datediff(selectedDay,payableDate)*0.001) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
									from device join deviceuser using (ID) join arrearagerecord using(DID)
									where deviceType=01 and selectedDay>payableDate and finish=0
									union
									/*02设备*/
									/*跨年*/
									select id, username, capital,(capital*(datediff(selectedDay,date_sub(selectedDay,interval dayofyear(now())-1 day))+1)*0.002
																			+capital*(datediff(date_sub(selectedDay,interval dayofyear(selectedDay)-1 day),payableDate))*0.003) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
									from device join deviceuser using (ID) join arrearagerecord using(DID)
									where deviceType=02 and year(payableDate)<year(selectedDay) and finish=0
									union
									/*未跨年*/
									select id, username,capital,(capital*(datediff(selectedDay,date_sub(@selectedDay,interval dayofyear(selectedDay)-1 day))+1)*0.002) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
									from device join deviceuser using (ID) join arrearagerecord using(DID)
									where deviceType=02 and year(payableDate)=year(selectedDay) and finish=0
									union
									select id, username, capital, overduefine,receivedAmount,arrearageDate,payableDate,payDate,DID,finish
									from device join deviceuser using (ID) join arrearagerecord using(DID)
									where finish=1) T
								where T.DID=p_DID and T.finish=0 order by payableDate asc limit 0,1;
                            
                            
                            if((p_paymentAmount+userBalance)>=(actualFee-p_receivedAmount)) then -- 如果付的费用能够支付这个月的
                                if (userBalance<(actualFee-p_receivedAmount)) then-- 余额不足支付，则用到支付金
                                    -- 更新余额变化表
                                    jump_lable1: begin
                                    if(userBalance=0) then
                                        leave jump_lable1;
                                    end if;
                                    insert into balancechangesrecord(ID,changeTime,beforeChange,afterChange,changeAmount,reason)
                                    values(p_ID, current_timestamp(),userBalance,0, userBalance,'01');
                                    
                                    end jump_lable1;
                                    set p_paymentAmount=p_paymentAmount-((actualFee-p_receivedAmount)-userBalance) ;
                                    set userBalance=0 ;
                                else
                                    insert into balancechangesrecord(ID,changeTime,beforeChange,afterChange,changeAmount,reason)
                                    values(p_ID, current_timestamp(),userBalance,userBalance-(actualFee-p_receivedAmount),(actualFee-p_receivedAmount),'01');
                                    set userBalance=userBalance-(actualFee-p_receivedAmount);
                                end if;
                                
                                update arrearagerecord
                                set receivedAmount=actualFee,actualReceivebleAmount=actualFee,payDate=selectedDay,overdueFine=(actualFee-capital),finish=1
                                where DID=p_DID and payableDate=p_payableDate;
                            else if((p_paymentAmount+userBalance)<(actualFee-p_receivedAmount)) then -- 费用不够支付这个月的
                                jump_lable2: begin
                                    if(userBalance=0) then
                                        leave jump_lable2;
                                    end if;
                                insert into balancechangesrecord(ID,changeTime,beforeChange,afterChange,changeAmount,reason)
                                values(p_ID, current_timestamp(),userBalance,0, userBalance,'01');
                                end jump_lable2;
                                
                                update   arrearagerecord
                                set     receivedAmount=p_receivedAmount+(p_paymentAmount+userBalance)
                                where DID=p_DID and payableDate=p_payableDate;
                                
                                set p_paymentAmount=0;
                                set userBalance=0 ;
                                end if;
                            end if;
                            if(p_paymentAmount<=0) then-- 如果支付金额已经未0，则直接跳出循环
                                leave outer_lable;
                            end if;
                        set i=i+1;
                        end while;
                    end if;
                 end outer_lable;
               
                  insert into paymentrecord (serialNumber,DID,bankID,accountNumber,paymentAmount,inDeviceAmount,paymentDate,reversal)
                  values(serialNumber,p_DID,p_bankID,p_accountNumber,p_paymentAmount2,(userBalance2-userBalance)+(p_paymentAmount2-p_paymentAmount),selectedDay,false);
                  if((userBalance+p_paymentAmount)>0) then-- 如果余额>0 即，未使用银行转入的金额，多余的金额加入账户余额，更新用户余额，插入余额变化记录
                   if(p_ID<>p_ID_to) then
                        select balance into userBalance from deviceuser where ID=p_ID;
                    end if;
                        insert into balancechangesrecord(ID,changeTime,beforeChange,afterChange,changeAmount,reason)
                        values(p_ID, current_timestamp(),userBalance,userBalance+p_paymentAmount, p_paymentAmount,'02');
                  end if;
                    
                    update deviceuser set balance=userBalance+p_paymentAmount
                    where ID=p_ID;
END;

