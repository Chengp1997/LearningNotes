CREATE PROCEDURE pay(IN p_ID INT, IN p_accountNumber INT, IN p_paymentAmount DOUBLE, IN p_DID INT, IN selectedDay DATE)
  BEGIN
    declare countDID int;
    declare notice varchar(500);
    declare countDate int;
    declare p_payableDate date;
    declare countAccount double;
    declare serialNum int;
    declare i int;
    declare p_bankID varchar(20) ;
    declare actualFee double;
    declare p_receivedAmount double;
    declare userBalance double;
    declare userBalance2 double;
    declare p_ID_to int;
    declare storeBalance double;
    -- 用于记录原值，用来最后更新用户余额以及缴费记录表
    declare p_paymentAmount2 double;
    set p_paymentAmount2=p_paymentAmount;
    
    -- 查找是否有此设备,该设备主人为谁
    select count(*),ID into countDID,p_ID_to from device where DID=p_DID;
    select bankID into p_bankID from bankaccount where accountNumber=p_accountNumber;
    
   
    if(countDID=0) then
        set notice='输入错误，本公司无此设备';
        select notice;
    else    -- 输入正确，选择卡号进行缴费
        select count(*) into countAccount from bankaccount where accountNumber=p_accountNumber and ID=p_ID;
        if(countAccount=0) then
            set notice='输入错误';
            select notice;
        else-- 进行缴费
            if(p_paymentAmount<0) then
                set notice='缴费金额错误，金额不能为负数';
                select notice;
            else
                    select serialNumber into serialNum from paymentrecord where reversal=0 order by serialNumber desc limit 0,1;-- 用于记录的序列号
                   
                    set serialNum=serialNum+1;
                    -- 先更新银行表格，银行清单表中需要增加一条缴费记录
                    insert into serialrecord(paymentDate,serialNumber,paymentAmount,accountNumber,bankID)
                    values(selectedDay,serialNum,p_paymentAmount,p_accountNumber,p_bankID);
                call commonPay(serialNum,p_ID,p_accountNumber,p_paymentAmount,p_DID,selectedDay);
            end if;
        end if;
    end if;
    
END;

