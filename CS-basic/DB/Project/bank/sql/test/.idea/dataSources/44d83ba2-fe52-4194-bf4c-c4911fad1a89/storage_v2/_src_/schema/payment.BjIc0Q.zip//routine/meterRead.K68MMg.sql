CREATE PROCEDURE meterRead(IN p_dateOfReadMeter DATE, IN p_DID INT, IN p_currentMeterAmount INT,
                           IN p_meterReader     VARCHAR(50))
  BEGIN

    declare userBalance double;
    declare accountNumber double;
    declare p_ID int;
    declare count int;
    declare p_username varchar(20);
    declare p_capital double;
    declare p_overduefine double;
    declare p_receivedAmount double;
    declare p_payableDate date;
    declare shouldPay double;
    declare counts int default 0;
    declare userBalanceBefore double;
    declare p_beginMeterAmount int;
    declare p_basicAmount double;
    declare appendFee2Rate double;
    declare p_deviceType varchar(5);
    declare notice varchar(20);
    declare i int;
    declare selectedDay date;
    
    select currentMeterAmount into p_beginMeterAmount from arrearagerecord where DID=p_DID order by payableDate desc limit 0,1;
    select count(*) into counts from arrearagerecord where DID=p_DID order by payableDate desc;
   if(counts=0) then
        set p_beginMeterAmount=0;
   end if;
   select deviceType into p_deviceType from device where DID=p_DID;
    exit_lable: begin
    if(p_currentMeterAmount<p_beginMeterAmount) then
        set notice='输入错误';
        select notice;
        leave exit_lable;
    end if;
    -- 生成抄表记录
    insert into meterrecord(DID, dateOfReadMeter, currentMeterAmount,meterReader)
    values(p_DID,p_dateOfReadMeter,p_currentMeterAmount,p_meterReader);
    if(p_deviceType='01') then
        set appendFee2Rate=0.1;
    else
        set appendFee2Rate=0.15;
    end if;
    
    select balance,ID into userBalance,p_ID from deviceuser join device using(ID) where DID=p_DID;-- 获得此用户余额
    set userBalanceBefore=userBalance;
   
-- 从余额扣费，将欠费记录补上   类似于缴费过程
   
    set p_basicAmount=(p_currentMeterAmount-p_beginMeterAmount)*0.46;
    insert into arrearagerecord(DID,arrearageDate,beginMeterAmount,currentMeterAmount,basicAmount,appendAmount1,
                                appendAmount2,capital,receivedAmount,payableDate)
                                values(p_DID,p_dateOfReadMeter,p_beginMeterAmount,p_currentMeterAmount,p_basicAmount,p_basicAmount*0.08,
                                       p_basicAmount*appendFee2Rate,p_basicAmount+ (p_basicAmount*0.08) +p_basicAmount*appendFee2Rate,0,
                                        date_sub(date_add(p_dateOfReadMeter - day(p_dateOfReadMeter) +1,interval 1 month ),interval 1 day));
    select count(*) into count from arrearagerecord where DID=p_DID and finish=0;
    set selectedDay =p_dateOfReadMeter;
    if(ifnull(count,0)>0) then -- 有欠费记录,补欠费记录
        if(userBalance>0) then
        set i=0;
            out_lable: begin
                while(i<ifnull(count,0)) do
                if(userBalance=0) then
                    leave out_lable;
                end if;
                select username, capital, overduefine, receivedAmount, payableDate, DID
                into p_username, p_capital, p_overduefine, p_receivedAmount, p_payableDate, p_DID
                from (select id, username,capital,(capital*0) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where  selectedDay<=payableDate and selectedDay>=arrearageDate and finish=0
                    union
                    /*01设备*/
                    /*超过应缴日期未还款*/
                    select id, username,capital,(capital*datediff(selectedDay,payableDate)*0.001) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=01 and selectedDay>payableDate and finish=0
                    union
                    /*02设备*/
                    /*跨年*/
                    select id, username, capital,(capital*(datediff(selectedDay,date_sub(selectedDay,interval dayofyear(now())-1 day))+1)*0.002
                                                            +capital*(datediff(date_sub(selectedDay,interval dayofyear(selectedDay)-1 day),payableDate))*0.003) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=02 and year(payableDate)<year(selectedDay) and finish=0
                    union
                    /*未跨年*/
                    select id, username,capital,(capital*(datediff(selectedDay,date_sub(selectedDay,interval dayofyear(@selectedDay)-1 day))+1)*0.002) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=02 and year(payableDate)=year(selectedDay) and finish=0
                    union
                    select id, username, capital, overduefine,receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where finish=1) T
                where T.DID=p_DID and T.finish=0
                order by payableDate asc
                limit 0,1;
                    -- 开始进行缴费操作
                    set shouldPay=p_capital+p_overduefine-p_receivedAmount;
                    if(userBalance>shouldPay) then -- 如果余额足够支付
                        set userBalance=userBalance-shouldPay;
                        
                        update arrearagerecord
                        set receivedAmount=p_capital+p_overduefine,actualReceivebleAmount=p_capital+p_overduefine,payDate=p_dateOfReadMeter,overdueFine=p_overduefine,finish=1
                        where DID=p_DID and payableDate=p_payableDate;
                    else
                        
                        update arrearagerecord
                        set receivedAmount=userBalance
                        where DID=p_DID and payableDate=p_payableDate;
                        set userBalance=0;
                        
                    end if;
                    
                    insert into balancechangesrecord(ID, changeTime,beforeChange,afterChange,changeAmount,reason)
                    values(p_ID, current_timestamp(),userBalanceBefore,userBalance,userBalanceBefore-userBalance,'01');
                    set userBalanceBefore=userBalance;
                    set i=i+1;
                    
                end while;
                end out_lable;
        end if;
        
         -- 生成欠费记录
    
         update deviceuser set balance=userBalance
         where ID=p_ID;
    end if;
    
    end exit_lable;
END;

