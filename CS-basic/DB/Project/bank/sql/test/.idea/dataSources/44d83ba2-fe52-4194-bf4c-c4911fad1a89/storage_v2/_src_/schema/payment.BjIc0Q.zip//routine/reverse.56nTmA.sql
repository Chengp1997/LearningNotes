CREATE PROCEDURE reverse(IN p_DID INT, IN p_serialNumber INT, IN selectedDay DATE)
  BEGIN
    
    declare countDID int;
    declare count int;
    declare countDate int;
    declare p_payableDate date;
    declare amount double;-- 设备最后更新缴费表时总共进入设备的钱
    declare p_inDeviceAmount_to double;
    declare p_inDeviceAmount_this double;
    declare p_inDeviceAmount_thisTotal double;
    declare p_accountNumber_to double;
    declare p_accountNumber_this double;
    declare p_paymentAmount_to double;  -- 要冲回的设备交的钱
    declare p_paymentAmount_this double;
    declare p_paymentAmount_thisTotal double; -- 交错的设备交的
    declare i int;
    declare p_bankID varchar(20);   
    declare actualFee double;
    declare p_receivedAmount double;
    declare userBalance_this double;
    declare userBalance_to double;
    declare p_ID_to int;
    declare p_ID_this int;
    declare p_DID_this int;
    declare totalAmount double default 0;
    declare p_capital double;
    declare p_username varchar(20);
    declare p_overduefine double;
    declare userBalanceBefore double;
    declare shouldPay double;
    declare p_serialNumber_this double;
    select count(*),DID into count,p_DID_this from paymentrecord where serialNumber=p_serialNumber; -- 公司是否有此记录
    select ID into p_ID_to from device where DID=p_DID; -- 要冲正回的设备的主人 2007
    select ID into p_ID_this from device where DID=p_DID_this;
    if(ifnull(count,0)<>0) then  -- 公司有此流水号记录，开始进行冲正操作
        select count(*) from paymentrecord where paymentDate=selectedDay; -- 找到今天所有的支付记录条数
        
        -- 对于付款者    可找到自己付款的卡号，付款的到别人账上的总金额    
        select accountNumber,paymentAmount,round(inDeviceAmount,2) ,bankID into p_accountNumber_to,p_paymentAmount_to ,p_inDeviceAmount_to,p_bankID
        from paymentrecord
        where serialNumber=p_serialNumber;
        -- 只需要拿回p_inDeviceAmount_to 便可
        select balance into userBalance_to from deviceuser where ID=p_ID_to;  -- 此人原本有多少余额
        update deviceuser
        set balance=userBalance_to+p_inDeviceAmount_to
        where ID=p_ID_to;
   
        if(p_inDeviceAmount_to<>0) then
            insert into balancechangesrecord(ID, changeTime,beforeChange,afterChange,changeAmount,reason)
            values (p_ID_to,current_timestamp(),userBalance_to,userBalance_to+p_inDeviceAmount_to,p_inDeviceAmount_to,'02');
        end if;
        update paymentrecord
        set reversal=1
        where serialNumber=p_serialNumber;
        
        -- 对于收款者，找到这台设备所有收的款， 进入设备的金额
        select round(ifnull(sum(paymentAmount),0),2) , round(ifnull(sum(inDeviceAmount),0),2),count(*)  into p_paymentAmount_thisTotal,p_inDeviceAmount_thisTotal,count
        from paymentrecord join device using(DID)
        where paymentDate=selectedDay and DID=p_DID_this;
        


        set p_inDeviceAmount_this=p_inDeviceAmount_thisTotal-p_inDeviceAmount_to;
        
        select balance into userBalance_this from deviceuser where ID=p_ID_this;
        update deviceuser
        set balance=userBalance_this+p_inDeviceAmount_this
        where ID=p_ID_this;
        
        if(p_inDeviceAmount_this<>0) then
            insert into balancechangesrecord(ID, changeTime,beforeChange,afterChange,changeAmount,reason)
            values (p_ID_this,current_timestamp(),userBalance_this,userBalance_this+p_inDeviceAmount_this,p_inDeviceAmount_this,'02');
        end if;
        
        select balance into userBalance_this from deviceuser where ID=p_ID_this;-- 此人有多少余额
        select count(*) into count from arrearagerecord where DID=p_DID_this and receivedAmount<>0;
      
        set i=0;
        out_lable: begin
        while(i<count) do
            
            select round(receivedAmount,2) ,round(capital+overduefine,2) ,payableDate into p_receivedAmount,actualFee,p_payableDate
            from (select id, username,capital,(capital*0) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where  selectedDay<=payableDate and selectedDay>=arrearageDate and finish=0
                    union
                    /*01设备*/
                    /*超过应缴日期未还款*/
                    select id, username,capital,(capital*datediff(selectedDay,payableDate)*0.001) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=01 and selectedDay>payableDate and finish=0
                    union
                    /*02设备*/
                    /*跨年*/
                    select id, username, capital,(capital*(datediff(selectedDay,date_sub(selectedDay,interval dayofyear(now())-1 day))+1)*0.002
                                                            +capital*(datediff(date_sub(selectedDay,interval dayofyear(selectedDay)-1 day),payableDate))*0.003) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=02 and year(payableDate)<year(selectedDay) and finish=0
                    union
                    /*未跨年*/
                    select id, username,capital,(capital*(datediff(selectedDay,date_sub(selectedDay,interval dayofyear(selectedDay)-1 day))+1)*0.002) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where deviceType=02 and year(payableDate)=year(selectedDay) and finish=0
                    union
                    select id, username, capital, overduefine,receivedAmount,arrearageDate,payableDate,payDate,DID,finish
                    from device join deviceuser using (ID) join arrearagerecord using(DID)
                    where finish=1) T
            where T.DID=p_DID_this and T.receivedAmount<>0
            order by T.payableDate desc
            limit 0,1;
            
            
            
            -- 更新欠费记录表回原样
            
            if(p_inDeviceAmount_thisTotal<=p_receivedAmount) then
                
                set p_receivedAmount=p_receivedAmount-p_inDeviceAmount_thisTotal;
                set p_inDeviceAmount_thisTotal=0;
            else
                set p_inDeviceAmount_thisTotal=p_inDeviceAmount_thisTotal-p_receivedAmount;
                set p_receivedAmount=0;
            end if;
            
            update arrearagerecord
            set actualReceivebleAmount=null, receivedAmount=p_receivedAmount, overdueFine=null, payDate=null,finish=0
            where DID=p_DID_this and receivedAmount<>0 and payableDate=p_payableDate
            order by payableDate desc;
            if( p_inDeviceAmount_thisTotal<=0) then
                leave out_lable;
            end if;
            set i=i+1;
        end while;
        end out_lable;
        
      select count(*) from paymentrecord join device using(DID) join deviceuser using(ID)  where ID=p_ID_this;
      set i=0;
      while(i<count) do
        select serialNumber into p_serialNumber_this
        from paymentrecord join device using(DID) join deviceuser using(ID)
        where accountNumber=p_accountNumber_this and paymentDate=selectedDay order by serialNumber asc limit i,1;
        select p_serialNumber_this;
        call balancePayForReverse(p_DID_this,p_serialNumber_this,selectedDay);
        set i=i+1;
      end while;
    end if;
END;

