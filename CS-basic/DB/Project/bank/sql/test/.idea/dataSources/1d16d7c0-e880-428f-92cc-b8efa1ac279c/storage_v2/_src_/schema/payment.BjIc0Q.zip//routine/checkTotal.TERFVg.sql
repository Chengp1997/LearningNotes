CREATE PROCEDURE checkTotal(IN p_bankID    VARCHAR(20), IN p_checkingTotal INT, IN p_checkingAmount DOUBLE,
                            IN p_checkDate DATE)
  BEGIN
    declare p_companyCheckingTotal int;
    declare p_companyCheckingAmount double;
    declare bankCount int;
   
    select count(*),ifnull(sum(paymentAmount),0) into p_companyCheckingTotal,p_companyCheckingAmount -- 计算公司交易笔数/交易金额
    from paymentrecord
    where paymentDate=DATE_SUB(p_checkDate,INTERVAL 1 DAY) and bankID=p_bankID ;
    
    insert into resultrecord(checkDate,companyCheckingTotal,checkingTotal,companyCheckingAmount,checkingAmount,success,bankID)
        values(p_checkDate, p_companyCheckingTotal,p_checkingTotal,p_companyCheckingAmount,p_checkingAmount,true,p_bankID);-- 如果成功，则插入成功的记录
    select curdate();
    if(!(p_companyCheckingTotal=p_checkingTotal&&p_companyCheckingAmount=p_checkingAmount))  then
        update  resultrecord  
        set success=false
        where checkDate=p_checkDate and bankID=p_bankID;
        
    end if;
        
END;

