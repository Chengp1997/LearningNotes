CREATE PROCEDURE check_detail(IN p_checkDate DATE, IN p_bankID VARCHAR(20))
  BEGIN
        DECLARE p_serialNumber int;
        DECLARE p_paymentAmount double;
        DECLARE p_accountNumber double;
        DECLARE done integer default 0;
        DECLARE count_check int;
        DECLARE bankrecordTotal int;
        DECLARE companyrecordTotal int;
        DECLARE companyCheckingAmount double;

        DECLARE myCursor1 cursor for
        select serialNumber, paymentAmount, accountNumber, bankID
        from serialrecord  
        where paymentDate=DATE_SUB(p_checkDate,INTERVAL 1 DAY);
        DECLARE myCursor2 cursor for
        select serialNumber, paymentAmount, accountNumber, bankID
        from paymentrecord
        where paymentDate=DATE_SUB(p_checkDate,INTERVAL 1 DAY);
        DECLARE continue HANDLER FOR NOT FOUND SET done=1;
        
        select companyCheckingTotal, checkingTotal into companyrecordTotal, bankrecordTotal
        from resultrecord
        where checkDate=p_checkDate and bankID=p_bankID;  -- 记录两个公司记录条数差，可判断是哪个公司少了记录
        if(companyrecordTotal>=bankrecordTotal) then-- 如果公司记录多，则银行方面记录缺失
            open myCursor2;
             fetch myCursor2 into p_serialNumber,p_paymentAmount,p_accountNumber,p_bankID;
             repeat
                
                select count(*) into count_check from serialrecord where serialNumber=p_serialNumber;
          
                if(ifnull(count_check,0)=0) then
                    insert into checkerrorrecord(serialNumber,checkDate,checkErrorReason,bankID)
                    values(p_serialNumber,p_checkDate,'01',p_bankID);
                else
                    select count(*) into count_check from serialrecord where paymentAmount=p_paymentAmount;
   
                    if(ifnull(count_check,0)=0) then
                        insert into checkerrorrecord(serialNumber,checkDate,checkErrorReason,bankID)
                        values(p_serialNumber,p_checkDate,'03',p_bankID);
                    end if;
                end if;
                
                fetch myCursor2 into p_serialNumber,p_paymentAmount,p_accountNumber,p_bankID;
                
            until done end repeat;
            close myCursor2;
        else
             open myCursor1;
             fetch myCursor1 into p_serialNumber,p_paymentAmount,p_accountNumber,p_bankID;
             repeat
               
                select count(*) into count_check from paymentrecord where serialNumber=p_serialNumber;
                if(ifnull(count_check,0)=0) then
                    insert into checkerrorrecord(serialNumber,checkDate,checkErrorReason,bankID)
                    values(p_serialNumber,p_checkDate,'02',p_bankID);
                else
                    select count(*) into count_check from paymentrecord where paymentAmount=p_paymentAmount;
                    if(ifnull(count_check,0)=0) then
                        insert into checkerrorrecord(serialNumber,checkDate,checkErrorReason,bankID)
                        values(p_serialNumber,p_checkDate,'03',p_bankID);
                    end if;
                end if;
                
                fetch myCursor1 into p_serialNumber,p_paymentAmount,p_accountNumber,p_bankID;
                
            until done end repeat;
            close myCursor1;
        end if;
        
       
        
END;

