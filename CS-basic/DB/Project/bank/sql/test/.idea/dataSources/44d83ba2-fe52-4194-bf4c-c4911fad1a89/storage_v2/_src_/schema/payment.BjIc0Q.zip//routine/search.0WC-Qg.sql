CREATE PROCEDURE search(IN p_ID INT, IN selectedDay DATE)
  BEGIN
     DECLARE notice varchar(500);
     declare recordNumber int ;
     declare existArrearge int;
     select count(*) into recordNumber from deviceuser where ID=p_ID;
     select count(*) into existArrearge from device join deviceuser using (ID) join arrearagerecord using(DID) where ID=p_ID and finish=0;-- 用于判断是否欠费
     
     if (recordNumber=0) then
        set notice='不存在此客户';
        select notice;
      else -- 找到此用户    
        if(existArrearge=0) then-- 如果该用户不欠费
            set notice='不欠费，欠费金额为0';
            select username as 用户名, address as 地址,selectedDay as 今日日期, notice
            from deviceuser
            where ID=p_ID;
        else
            select username as 用户名, address as 地址, round(sum(capital+overdueFine),2) as 应收费用, round(SUM(receivedAmount),2) AS 实收费用, @selectedDay as 今日日期
             from (select id,address, username,capital,(capital*0) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
				from device join deviceuser using (ID) join arrearagerecord using(DID)
				where  selectedDay<=payableDate and selectedDay>=arrearageDate and finish=0
				union
				/*01设备*/
				/*超过应缴日期未还款*/
				select id,address, username,capital,(capital*datediff(selectedDay,payableDate)*0.001) as overduefine, receivedAmount,arrearageDate, payableDate, payDate,DID,finish
				from device join deviceuser using (ID) join arrearagerecord using(DID)
				where deviceType=01 and selectedDay>payableDate and finish=0
				union
				/*02设备*/
				/*跨年*/
				select id,address, username, capital,(capital*(datediff(selectedDay,date_sub(selectedDay,interval dayofyear(now())-1 day))+1)*0.002
														+capital*(datediff(date_sub(selectedDay,interval dayofyear(selectedDay)-1 day),payableDate))*0.003) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
				from device join deviceuser using (ID) join arrearagerecord using(DID)
				where deviceType=02 and year(payableDate)<year(selectedDay) and finish=0
				union
				/*未跨年*/
				select id,address, username,capital,(capital*(datediff(selectedDay,date_sub(@selectedDay,interval dayofyear(selectedDay)-1 day))+1)*0.002) as overduefine, receivedAmount,arrearageDate,payableDate,payDate,DID,finish
				from device join deviceuser using (ID) join arrearagerecord using(DID)
				where deviceType=02 and year(payableDate)=year(selectedDay) and finish=0
				union
				select id,address, username, capital, overduefine,receivedAmount,arrearageDate,payableDate,payDate,DID,finish
				from device join deviceuser using (ID) join arrearagerecord using(DID)
				where finish=1) T
            where T.ID=p_ID ;
        end if;
     end if;
            
END;

